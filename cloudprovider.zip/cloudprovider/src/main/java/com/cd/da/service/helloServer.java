package com.cd.da.service;

public interface helloServer {

	
	public String hello();
}
