package com.cd.da.serviceImp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cd.da.Repository.UserRepository;
import com.cd.da.bean.User;
import com.cd.da.service.UserService;

@Service
public class UserServiceImp  implements UserService{

	@Autowired
	UserRepository userRepositoryImpl ;
	
	
	public User findUser(Long id) {
		// TODO Auto-generated method stub
		return null;
	}


	public List<User> myCustomBatchOperation() {
		// TODO Auto-generated method stub
		return userRepositoryImpl.myCustomBatchOperation();
	}


	public int insertUser(User use) {
		// TODO Auto-generated method stub
		return userRepositoryImpl.insertUser(use);
	}

	
	
}
