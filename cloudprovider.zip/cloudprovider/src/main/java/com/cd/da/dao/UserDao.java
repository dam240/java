package com.cd.da.dao;

import java.util.List;

import com.cd.da.bean.User;

public interface UserDao {
	public List<User> myCustomBatchOperation() ;
	
	public int insertUser(User use);
}
