package com.cd.da.serviceImp;

import org.springframework.stereotype.Service;

import com.cd.da.service.helloServer;
@Service
public class helloServerImp  implements helloServer{

	public String hello() {
		// TODO Auto-generated method stub
		return "hello get spring cloud";
	}

}
