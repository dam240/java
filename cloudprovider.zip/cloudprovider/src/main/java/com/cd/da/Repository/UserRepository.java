package com.cd.da.Repository;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Component;

import com.cd.da.bean.User;
import com.cd.da.dao.UserDao;

@Component("userRepositoryImpl")
public class UserRepository   implements UserDao{
	
	  @Autowired
	    private JdbcTemplate jdbcTemplate;
	
	private static final String COMPLICATED_SQL = "SELECT * FROM user";

	public List<User> myCustomBatchOperation() {
		return jdbcTemplate.query(COMPLICATED_SQL, new UserRowMapper());
	}


	 

	
	
	private static class UserRowMapper implements RowMapper<User> {
		/*
		 * (non-Javadoc)
		 * @see org.springframework.jdbc.core.RowMapper#mapRow(java.sql.ResultSet, int)
		 */
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {

			User user = new User();
		   user.setId(rs.getLong("id"));
		   user.setName(rs.getString("name"));
			return user;
		}

	}






	public int insertUser(User use) {
		// TODO Auto-generated method stub
		return   jdbcTemplate.update("insert  into  user(name) values(?)", new Object[]{
		 use.getName()
     },new int[]{
		 java.sql.Types.VARCHAR	 
    });
		
	}

}
