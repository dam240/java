package com.cd.da.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cd.da.service.helloServer;

@RestController
public class helloController {
    @Autowired
	helloServer helloserver;
    
    @GetMapping("/hellos")
    public String hellos() {
    	  
    	  
        String services = "Services: " + helloserver.hello();
        System.out.println(services);
        
     
        return services;
    }
    
}
