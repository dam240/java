package com.cd.da.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cd.da.bean.Result;
import com.cd.da.bean.User;
import com.cd.da.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService userService;
	
    static Logger logger = LoggerFactory.getLogger(UserController.class);

	  @RequestMapping("/user/insert")
	    public Result insert(@RequestBody User us) {
		  logger.info("============="+us.getName());
		  if(userService.insertUser(us)!=0)
			  return Result.Ok;
		  
	        return Result.err;
	    }
	  
	  @RequestMapping("/user/allInfo")
	   public List<User> allInfo(){
		   return userService.myCustomBatchOperation();
	   }
	
}
