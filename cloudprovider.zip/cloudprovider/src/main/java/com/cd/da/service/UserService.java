package com.cd.da.service;

import java.util.List;

import com.cd.da.bean.User;

public interface UserService {

	
	public User findUser(Long id);
	
	public List<User> myCustomBatchOperation() ;
	
	public int insertUser(User use);
}
