package com.cd.da.remote;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cd.da.bean.Result;
import com.cd.da.bean.User;

@Component
public class UserRemoteHystrix implements UserRemote{

	  
	

	public List<User> allInfo() {
		// TODO Auto-generated method stub
		return  new ArrayList<User>();
	}


	public Result insert(User use) {
		// TODO Auto-generated method stub
		return Result.err;
	}
}
