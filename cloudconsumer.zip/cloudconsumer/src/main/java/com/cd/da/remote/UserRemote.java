package com.cd.da.remote;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cd.da.bean.Result;
import com.cd.da.bean.User;
import com.cd.da.controller.UserController;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
@FeignClient(name= "cloudprovider" ,fallback = UserRemoteHystrix.class)
public  interface UserRemote {

	  
    static Logger logger = LoggerFactory.getLogger(UserRemote.class);
	
	  @RequestMapping(value = "/user/allInfo")
	  public   List<User>  allInfo();
	  
	  @RequestMapping(value = "/user/insert")
	  public  Result  insert(@RequestBody User use);
	
}
