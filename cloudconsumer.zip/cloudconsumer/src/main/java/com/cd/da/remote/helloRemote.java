package com.cd.da.remote;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;

@FeignClient(name= "cloudprovider", fallback = helloRemoteHystrix.class)
public interface helloRemote {
	@RequestMapping(value = "/hellos")
    public String hellos();
}
