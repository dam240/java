package com.cd.da.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cd.da.bean.Result;
import com.cd.da.bean.User;
import com.cd.da.remote.UserRemote;
@Controller
public class UserController {
	@Autowired
	UserRemote useRemote;
    static Logger logger = LoggerFactory.getLogger(UserController.class);

   @RequestMapping("/allInfo")
	public  String allInfo(HttpServletRequest request){
	     request.setAttribute("list",  useRemote.allInfo());
		return  "pages/userlist";
	}
	
   @RequestMapping("/insertUser")
	public String  insertUser(User use){
	  
	   logger.info(use.getName());
	   
	   if(useRemote.insert(use).getResultcond()==Result.err.getResultcond()){
		  return "pages/result/error";
	   }
		return "pages/result/succse";
	}
   
   @RequestMapping("/index")
   public String  index(HttpServletRequest request){
	   request.setAttribute("name", "hello");
	   return "pages/index";
   }
   
   @RequestMapping("/registe")
   public  String  registe(){
	   return "pages/user/registe";
   }
	
}
