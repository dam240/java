package com.cd.da.bean;

public enum Result {
	
	Ok(100,"成功"),
	err(777,"err") ;
	
	private int resultcond;
	private String resultmsg;
	Result(int resultcond, String resultmsg) {
		this.resultcond = resultcond;
		this.resultmsg = resultmsg;
	}
	public int getResultcond() {
		return resultcond;
	}
	public void setResultcond(int resultcond) {
		this.resultcond = resultcond;
	}
	public String getResultmsg() {
		return resultmsg;
	}
	public void setResultmsg(String resultmsg) {
		this.resultmsg = resultmsg;
	}

}
