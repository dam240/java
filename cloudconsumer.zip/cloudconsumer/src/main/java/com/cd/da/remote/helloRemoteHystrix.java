package com.cd.da.remote;

import org.springframework.stereotype.Component;

@Component
public class helloRemoteHystrix implements helloRemote {

	public String hellos() {
		// TODO Auto-generated method stub
		return "hello this messge send failed ";
	}

}
